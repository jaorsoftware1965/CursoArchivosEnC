// Curso de Archivos en C
// c16 ArchivosBinariosConfreadfwriteII

// En esta clase veremos como manejar un archivo de texto pero en modo binario, que es la forma
// más optima y exacta de manejar información.

// Incluimos las librerias necesarias
#include "stdio.h"

// Para manejo de memoria dinámica
#include "string.h"

// Función principal
int main () 
{
  
  // Datos a grabar
  char  strNombre[20]="Juan Alberto";
  char  strApellido[20]="Escutia Perez";
  int   intEdad=45;
  float fltPeso=75.40;
  char  chrSexo='H';
  char  chrEdoCivil='C';
  char  chrFinLinea='\n';

  // Longitud del Registro
  int iLongitudRegistro;
    
  // Apuntador a FILE
  FILE *pFile;     
  
  // Elementos a grabar
  int iElementos=1;
  
  // Resultado
  size_t r1,r2,r3,r4,r5,r6,r7;

  // Mensaje de Apertura de Archivos
  printf("Creando Archivo de Escritura/Lectura...\n");
  
  // Abrimos el archivo en modo binario de Lectura
  pFile = fopen ( "datos.dat" , "wb+" );
  
  
  // Verifica apertura correcta
  if (pFile ==NULL) 
  {
	  // Mensaje de Error
	  printf ("Error en Creación de Archivo"); 
	  return 0;	  
  }
  
  // Calculamos la longitud del Registro
  iLongitudRegistro  = sizeof(strNombre);
  printf("Longitud del Registro:%d [Nombre]\n",iLongitudRegistro);
  iLongitudRegistro += sizeof(strApellido);
  printf("Longitud del Registro:%d [Apellido]\n",iLongitudRegistro);
  iLongitudRegistro += sizeof(intEdad);
  printf("Longitud del Registro:%d [Edad]\n",iLongitudRegistro);
  iLongitudRegistro += sizeof(fltPeso);
  printf("Longitud del Registro:%d [Peso]\n",iLongitudRegistro);
  iLongitudRegistro += sizeof(chrSexo);
  printf("Longitud del Registro:%d [Sexo]\n",iLongitudRegistro);
  iLongitudRegistro += sizeof(chrEdoCivil);
  printf("Longitud del Registro:%d [EdoCivil]\n",iLongitudRegistro);
  iLongitudRegistro += sizeof(chrFinLinea);
  printf("Longitud del Registro:%d [FinLinea]\n",iLongitudRegistro);
  getch();
    
  
  // Mensaje de Grabación
  printf("Grabando 1er Registro \n");
  
  // Grabamos el los datos
  r1 = fwrite (strNombre,sizeof(strNombre),iElementos,pFile);
  r2 = fwrite (strApellido,sizeof(strApellido),iElementos,pFile);
  r3 = fwrite (&intEdad,sizeof(intEdad),iElementos,pFile);
  r4 = fwrite (&fltPeso,sizeof(fltPeso),iElementos,pFile);
  r5 = fwrite (&chrEdoCivil,sizeof(chrEdoCivil),iElementos,pFile);
  r6 = fwrite (&chrSexo,sizeof(chrSexo),iElementos,pFile);
  r7 = fwrite (&chrSexo,sizeof(chrFinLinea),iElementos,pFile);
  
  // Verificamos que no haya habido error
  if (r1+r2+r3+r4+r5+r6+r7 !=7)
  // Verifica si hubo algún error  
  {
	  // Mensaje de Error
	  printf("Error al Grabar en el Archivo"); 
	  return 0;	  
  }
  getch();
  
  // Actualizamos el Registro
  strcpy(strNombre,"Marco Antonio");
  strcpy(strApellido,"Ramirez Rodriguez");
  intEdad=24;
  fltPeso=55.90;
  chrSexo='H';
  chrEdoCivil='S';

  
  // Mensaje de Grabación
  printf("Grabando 2do Registro \n");
  
  // Grabamos el los datos
  r1 = fwrite (strNombre,sizeof(strNombre),iElementos,pFile);
  r2 = fwrite (strApellido,sizeof(strApellido),iElementos,pFile);
  r3 = fwrite (&intEdad,sizeof(intEdad),iElementos,pFile);
  r4 = fwrite (&fltPeso,sizeof(fltPeso),iElementos,pFile);
  r5 = fwrite (&chrEdoCivil,sizeof(chrEdoCivil),iElementos,pFile);
  r6 = fwrite (&chrSexo,sizeof(chrSexo),iElementos,pFile);
  r7 = fwrite (&chrSexo,sizeof(chrFinLinea),iElementos,pFile);
  
  // Validando Error
  if (r1+r2+r3+r4+r5+r6+r7 !=7)
  {
	  // Mensaje de Error
	  printf("Error al Grabar en el Archivo"); 
	  return 0;	  
  }
  getch();
  
  // Actualizamos el Registro
  strcpy(strNombre,"Maria Elena");
  strcpy(strApellido,"Flores Maldonado");
  intEdad=44;
  fltPeso=65.90;
  chrSexo='M';
  chrEdoCivil='C';

  
  // Mensaje de Grabación
  printf("Grabando 3er Registro \n");
  
  // Grabamos el los datos
  r1 = fwrite (strNombre,sizeof(strNombre),iElementos,pFile);
  r2 = fwrite (strApellido,sizeof(strApellido),iElementos,pFile);
  r3 = fwrite (&intEdad,sizeof(intEdad),iElementos,pFile);
  r4 = fwrite (&fltPeso,sizeof(fltPeso),iElementos,pFile);
  r5 = fwrite (&chrEdoCivil,sizeof(chrEdoCivil),iElementos,pFile);
  r6 = fwrite (&chrSexo,sizeof(chrSexo),iElementos,pFile);
  r7 = fwrite (&chrSexo,sizeof(chrFinLinea),iElementos,pFile);
  
  
  // Validando Error
  if (r1+r2+r3+r4+r5+r6+r7 !=7)
  {
	  // Mensaje de Error
	  printf("Error al Grabar en el Archivo"); 
	  return 0;	  
  }
  getch();
  
  // Colocamos el apuntador al principio
  printf("Posicionando en 3er Registro ...\n");
  fseek(pFile,2*(iLongitudRegistro),SEEK_SET);
  getch();

  
  // Mensaje de Grabación
  printf("Leyendo 3er Registro \n");
  
  // Leemos los datos
  r1 = fread (strNombre,sizeof(strNombre),iElementos,pFile);
  r2 = fread (strApellido,sizeof(strApellido),iElementos,pFile);
  r3 = fread (&intEdad,sizeof(intEdad),iElementos,pFile);
  r4 = fread (&fltPeso,sizeof(fltPeso),iElementos,pFile);
  r5 = fread (&chrEdoCivil,sizeof(chrEdoCivil),iElementos,pFile);
  r6 = fread (&chrSexo,sizeof(chrSexo),iElementos,pFile);
  
  // Validando Error
  if (r1+r2+r3+r4+r5+r6 !=6)
  {
	  // Mensaje de Error
	  printf("Error al Leer del Archivo"); 
	  return 0;	  
  }
  
  // Desplegamos los datos
  printf("Nombre    :%s [%d]\n",strNombre,strlen(strNombre));
  printf("Apellido  :%s [%d]\n",strApellido,strlen(strApellido));
  printf("Edad      :%d\n",intEdad);
  printf("Peso      :%f\n",fltPeso);
  printf("Edo Civil :%c\n",chrEdoCivil);
  printf("Sexo      :%c\n",chrSexo);
  getch();
  
  // Colocamos el apuntador en el 2do
  printf("Posicionando en 2do Registro ...\n");
  fseek(pFile,1*(iLongitudRegistro),SEEK_SET);
  getch();
  
  // Mensaje de Grabación
  printf("Leyendo 2do Registro \n");
  
  // Leemos los datos
  r1 = fread (strNombre,sizeof(strNombre),iElementos,pFile);
  r2 = fread (strApellido,sizeof(strApellido),iElementos,pFile);
  r3 = fread (&intEdad,sizeof(intEdad),iElementos,pFile);
  r4 = fread (&fltPeso,sizeof(fltPeso),iElementos,pFile);
  r5 = fread (&chrEdoCivil,sizeof(chrEdoCivil),iElementos,pFile);
  r6 = fread (&chrSexo,sizeof(chrSexo),iElementos,pFile);
  
  // Validando Error
  if (r1+r2+r3+r4+r5+r6 !=6)
  {
	  // Mensaje de Error
	  printf("Error al Leer del Archivo"); 
	  return 0;	  
  }
  getch();
  
  // Desplegamos los datos
  printf("Nombre    :%s [%d]\n",strNombre,strlen(strNombre));
  printf("Apellido  :%s [%d]\n",strApellido,strlen(strApellido));
  printf("Edad      :%d\n",intEdad);
  printf("Peso      :%f\n",fltPeso);
  printf("Edo Civil :%c\n",chrEdoCivil);
  printf("Sexo      :%c\n",chrSexo);
  getch();
  
  // Colocamos el apuntador al principio
  printf("Posicionando en 1er Registro ...\n");
  fseek(pFile,0,SEEK_SET);
  getch();

  // Mensaje de lectura
  printf("Leyendo 1er Registro \n");
  
  // Leemos los datos
  r1 = fread (strNombre,sizeof(strNombre),iElementos,pFile);
  r2 = fread (strApellido,sizeof(strApellido),iElementos,pFile);
  r3 = fread (&intEdad,sizeof(intEdad),iElementos,pFile);
  r4 = fread (&fltPeso,sizeof(fltPeso),iElementos,pFile);
  r5 = fread (&chrEdoCivil,sizeof(chrEdoCivil),iElementos,pFile);
  r6 = fread (&chrSexo,sizeof(chrSexo),iElementos,pFile);
  
  // Validando Error
  if (r1+r2+r3+r4+r5+r6 !=6)
  {
	  // Mensaje de Error
	  printf("Error al Leer del Archivo"); 
	  return 0;	  
  }
  
  // Desplegamos los datos
  printf("Nombre    :%s [%d]\n",strNombre,strlen(strNombre));
  printf("Apellido  :%s [%d]\n",strApellido,strlen(strApellido));
  printf("Edad      :%d\n",intEdad);
  printf("Peso      :%f\n",fltPeso);
  printf("Edo Civil :%c\n",chrEdoCivil);
  printf("Sexo      :%c\n",chrSexo);
  getch();
  
  // Cierra el Archivo
  fclose (pFile);
  
  // Finaliza la Aplicación
  return 0;
  
}