// Curso de Archivos en C
// c09 Escritura y Lectura con Formato

// En esta clase veremos la lectura y escritura de Archivos con formato
// utilizando las funciones fscanf y fprintf, para lo cual se debe tener
// conocimiento de como funciona printf y scanf; ya que su funcionamiento
// es similar, solo que en este caso; orientado a entrada y salida en archivo.

// La sintaxis de las 2 instrucciones son las siguientes:

// int fprintf ( FILE * stream, const char * format, ... )
// int fscanf ( FILE * stream, const char * format, ... );

// En el caso de fprintf, el valor que devuelve indica cuantos caracteres se grabaron y
// devuelve -1 en caso de Error

// En el caso de fscanf, el valor que devuelve indica el número de variables que se leyeron
// y devuelve -1 en caso de Error

// Incluimos la librería de Entrada y Salida Estandar de C
#include "stdio.h"

// Incluimos la libreria para funciones de Cadenas
#include "string.h"

// Función Principal
int main()
{
   // Imprime mensaje de la Clase
   printf("C09 Escribiendo y Leyendo con Formato \n \n");

   // Variable para archivo    
   FILE *pFile;

   // Datos a Grabar en el Archivo
   char  strNombre[20]="Juan";
   char  strApellido[20]="Escutia";
   int   intEdad=45;
   float fltPeso=75.40;
   char  chrSexo='H';
   char  chrEdoCivil='C';

   // Para saber cuantos caracteres se grabaron o cuantas variables se leyeron
   int iContador=0;
   
   // Abre el Archivo Original
   pFile = fopen ("Datos.txt", "w+");
   
   // Verifica que haya podido abrir el archivo
   if (pFile == NULL) 
   {
       // Mensaje de Error
       printf("Error al abrir el Archivo \n");
   }   
   else 
   {
       // Graba los datos
       iContador = fprintf(pFile, "%s %s %d %f %c %c\n",strNombre,strApellido,intEdad,fltPeso,chrSexo,chrEdoCivil);

       // Despliega cuantos caracteres se grabaron
       printf("Caracteres grabados:%d \n",iContador);

       // Actualizamos a otros datos
       strcpy(strNombre, "Laura");
       strcpy(strApellido, "Flores");
       intEdad = 49;
       fltPeso = 80.50;
       chrSexo ='M';
       chrEdoCivil='S';
    
       // Graba los datos
       iContador  = fprintf(pFile, "%s %s %d %f %c %c\n",strNombre,strApellido,intEdad,fltPeso,chrSexo,chrEdoCivil);
       
       // Despliega cuantos caracteres se grabaron
       printf("Caracteres grabados:%d \n",iContador);
       
       // Retorna el apuntador del Archivo al Principio
       rewind(pFile);

       // Lee los datos
       iContador = fscanf (pFile, "%s %s %d %f %c %c",strNombre,strApellido,&intEdad,&fltPeso,&chrSexo,&chrEdoCivil);

       // Despliega cuantas variables se Leyeron
       printf("Variables Leidas:%d \n",iContador);
              
       // Imprimiendo los datos
       printf("Nombre:%s Apellido:%s Edad:%d Peso:%f ",strNombre,strApellido,intEdad,fltPeso);
       printf("Sexo:%c EdoCivil:%c\n\n",chrSexo,chrEdoCivil);

       // Lee los datos
       iContador = fscanf (pFile, "%s %s %d %f %c %c",strNombre,strApellido,&intEdad,&fltPeso,&chrSexo,&chrEdoCivil);
       
       // Despliega cuantas variables se Leyeron
       printf("Variables Leidas:%d \n",iContador);

       // Imprimiendo los datos
       printf("Nombre:%s Apellido:%s Edad:%d Peso:%f ",strNombre,strApellido,intEdad,fltPeso);
       printf("Sexo:%c EdoCivil:%c\n",chrSexo,chrEdoCivil);

       // Cierra el Archivo
       fclose(pFile);       
   }

   
   // Finaliza la Aplicación
   return 0;
}
