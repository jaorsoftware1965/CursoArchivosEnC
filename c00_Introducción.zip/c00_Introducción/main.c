// Curso de Archivos en C
// c00 Introducción

// Un Archivo es un conjunto de información que se encuentra almacenada en memoria secundaria;
// es decir en Disco.

// En forma general, los archivos se clasifican en 2 tipos: de Texto y Binarios.

// Un Archivo de Texto es simplemente una secuencia de bytes, en donde cada byte es interpretado
// como un caracter. Por lo general, esta secuencia de caracteres se encuentran organizadas 
// en bloques finalizados por el caracter de cambio de linea "\n". (Líneas)

// Los archivos fuentes de los lenguajes de programación como este, son archivos de Texto;
// nombrados tambien "archivos planos o archivos de texto planos".

// Un archivo binario, es una secuencia de bytes (en binario) que no son interpretados como 
// caracteres; y que tienen un significado especial, dependiendo del uso que tengan. 
// Por ejemplo; un programa ejecutable es un archivo, en donde su secuencia de bytes son 
// interpretadas por el Sistema Operativo como instrucciones a ejecutar. 
// Un archivo de imagen, PNG por ejemplo, es un conjunto de bytes que es intepretado por un 
// programa de dibujo como PAINT y que representan una imagen.

// En C, no existen palabras reservadas del Lenguaje que nos permitan manejar archivos; esto
// se realiza a través de la librería estándar de C: "stdio.h" (Standar Input Output)

// Cabe mecionar que este curso de archivos es válido para cualquier Sistema Operativo (Linux,
// Windows, Mac); cualquier IDE (CodeBlocks, Dev C, NetBeans) y cualquier compilador de C 
// estandar
 

// Incluimos la librería de Entrada y Salida Estandar de C
#include "stdio.h"

// Función Principal de C
int main()
{
    // Mensaje de la Aplicación
    printf("c01 Introduccion al Curso de Archivos en C\n");

    // Salida de la Aplicación
    return 0;
}