// Curso de Archivos en C
// c01 Estructura FILE

// C maneja una Estructura específica para el manejo de Archivos; y que es la estructura FILE.
// Esta estructura se encuentra definida en el archivo stdio.h y esta es su definición:

// typedef struct _iobuf
// {
// 	 char*	_ptr;       // Posición del Apuntador
//	 int	_cnt;       // 
//	 char*	_base;      // Apuntador a la Base del Archivo
//	 int	_flag;      // _F_READ = 0x0001, _F_WRIT = 0x0002, _F_RDWR = 0x0003, _F_ERR = 0x0010, _F_EOF = 0x0020, _F_BIN = 0x0040};
//	 int	_file;      // Manejador del Archivo
//	 int	_charbuf;   // Buffer del Archivo
//	 int	_bufsiz;    // Tamaño del Buffer
//	 char*	_tmpfname;  // Nombre temporal del Archivo
// } FILE;

// Para poder acceder a los archivos, necesitamos declarar una variable apuntador a esta
// estructura, de la siguiente forma:

// FILE *pFile;

// Lo anterior creará una variable apuntador a FILE, que es requerida por las funciones
// de archivo.

// Para abrir un archivo se hace uso de la función fopen, la cual su sintaxis es la siguiente:

// FILE *fopen(const char *filename, const char *mode)

// Esta función como se observa en su definición, el valor que devuelve es un apuntador a FILE.
// Esta es una de las razones por la cual la variable para manejar archivos debe ser un apuntador
// a FILE.
// El parámetro *filename es el nombre del archivo a abrir y el *mode; es el modo de operación
// en que se abrirá el archivo. Para este clase veremos el modo "r"; que significa que el 
// archivo será abierto para operaciones de Lectura (r=read); es decir que solo podremos
// realizar lectura del archivo, aunque en esta clase solo lo abriremos sin leerlo.

// La función fopen devolverá NULL si no pudo realizar la apertura del Archivo.

// Incluimos la librería de Entrada y Salida Estandar de C
#include "stdio.h"

// Función Principal de C
int main()
{
    // Mensaje de la Aplicación
    printf("c01 Estructura FILE \n");

    // Declaramos la Variable del Puntero a File
    FILE *pFile;

    // Abrimos este mismo archivo para lectura
    pFile = fopen("main.c","r");

    // Verifica que pudo abrir el Archivo
    if (pFile==NULL)
    {
        // Mensaje de que hubo un error
        printf("Error al Abrir el Archivo  \n");
    }
    else
    {
        // Mensaje de Exito al Abrir el Archivo
        printf("El archivo se abrio correctamente  \n");
        printf("Informacion de la Estructura del Archivo:\n");
        printf("_ptr     :%s \n",pFile->_ptr);
        printf("_cnt     :%d \n",pFile->_cnt);
        printf("_base    :%s \n",pFile->_base);
        printf("_flag    :%d \n",pFile->_flag);
        printf("_file    :%d \n",pFile->_file);
        printf("_charbuf :%d \n",pFile->_charbuf);
        printf("_bufsiz  :%d \n",pFile->_bufsiz);
        printf("_tmpfname:%s \n",pFile->_tmpfname);            

        // Cierra el Archivo
        fclose(pFile);    
    }
    
    // Salida de la Aplicación
    return 0;
}