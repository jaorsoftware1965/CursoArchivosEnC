// Curso de Archivos en C
// c06 Escribiendo Archivos Caracter por Caracter
// En esta clase veremos como leer un Archivo de Texto caracter por caracter
// y escribir en un Archivo Caracter por Caracter para generar una copia.
// La sintaxis de la función para escribir un caracter es:
// int fputc ( int character, FILE * stream );
// La función devuelve el caracter escrito, y necesita como parámetro el apuntador a FILE.
// Si un error ocurre al realizar la escritura devuelve el valor EOF

// Incluimos la librería de Entrada y Salida Estandar de C
#include "stdio.h"

// Función Principal de C
int main()
{
    // Mensaje de la Aplicación
    printf("c06 Escribiendo Archivos Caracter Por Caracter \n");

    // Declaramos la Variables para los 2 Archivos
    FILE *pFileLectura;
    FILE *pFileEscritura;

    // Variable para contar los carateres
    int iCuenta=0;

    // Para leer y grabar caracter
    int iCaracterLeido;
    int iCaracterGrabado;

    // Abrimos este mismo archivo para lectura
    pFileLectura = fopen("main.c","r");

    // Verifica que pudo abrir el Archivo
    if (pFileLectura==NULL)
    {
        // Mensaje de que hubo un error
        printf("Error al Abrir el Archivo de Lectura \n");
    }
    else
    {
        // Abre el Archivo de Escritura
        pFileEscritura = fopen("mainCopy.c","w");
    
        // Verifica que pudo abrir el Archivo
        if (pFileEscritura==NULL)
        {
            // Mensaje de que hubo un error
            printf("Error al Crear el Archivo de Escritura \n");
        }
        else
        {
            // Ciclo para leer los caracteres hasta el final; otro método
            printf("Leyendo Caracteres ...\n");
            do
            {
                // Lee un caracter
                iCaracterLeido = fgetc(pFileLectura);
                
                // Imprimimos un punto e incrementamos contador
                printf(".");
                iCuenta++;

                // Verifica que no haya alcanzado el fin de Archivo
                if (iCaracterLeido!=EOF)
                {                    

                    // Grabamos el caracter
                    iCaracterGrabado = fputc(iCaracterLeido,pFileEscritura);

                    // Verifica si son distintos
                    if (iCaracterGrabado != iCaracterLeido)
                    {
                        // Mensaje de Error
                        printf("Ocurrió un Error al Grabar el Caracter");

                        // Finaliza
                        return 0;
                    }
                }
            }while (iCaracterLeido!=EOF);

            // Mensaje de Finalización
            printf("\nFin de Copia de Archivo \n");
            printf("Caracteres copiados:%d",iCuenta);

            // Cierra los Archivos
            fclose(pFileLectura);    
            fclose(pFileEscritura);    
        }    
    }
    // Salida de la Aplicación
    return 0;
}