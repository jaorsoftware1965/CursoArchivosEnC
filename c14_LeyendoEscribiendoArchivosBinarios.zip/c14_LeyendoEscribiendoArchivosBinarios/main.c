// Curso de Archivos en C
// c14 Leyendo y Escribiendo Archivos Binarios

// En la clase inicial, se explicó la diferencia entre un archivo de texto y un archivo
// binario. 

// Tambien en clases previas, se indicó que para manejar archivos binarios, se deben de
// utilizar las funciones fwrite y fread; pero en esta clase veremos que es posible usarse
// las funciones vistas anteriormente para manejar archivos binarios.

// Las funciones de manejo de archivos binarios; tienen una gran ventaja; puede usarse para 
// los archivos específicamente binarios como lo son los archivos .exe; .bmp; etc; pero 
// tambien es posible utilizarlos para manejar archivos de texto.

// En viceversa es posible pero no optimo; porque los archivos binarios; contendrán caracteres
// que no podrán ser interpretados para ser presentados como Texto; porque muchos de estos
// valores corresponderán a caracteres NO IMPRIMIBLES. En el código ASCII BASE; los caracteres
// del 0 al 31 y el 127 son No imprimibles; y si se usa el extendido; el 255 tampoco lo es.

// En el caso de que al leer un archivo binario; como por ejemplo un .exe; como si fuera de 
// texto; este contendrá posiblemente el valor 26; el cual indica; en modo texto;  que
// hubo una lectura inválida o erronea en el dispositivo

// Incluimos la librería de Entrada y Salida Estandar de C
#include "stdio.h"

// Incluimos la libreria para funciones de Cadenas
#include "string.h"

// Función Principal
int main()
{    
   // Imprime mensaje de la Clase
   printf("C14 Leyendo Archivos Binarios \n\n");
   
   // Variable para Contar Caracteres
   int iCuenta=0;

   // Variablera para Leer el Caracter
   int iCaracter;   

   // Modo de Apertura
   char strModoLectura[5];
   char strModoEscritura[5];

   // Apuntadores de Archivo
   FILE *pFileLectura,*pFileEscritura;
   
   // Solicita modos de Apertura
   printf("Captura el Modo de Lectura:");// rb es el correcto
   gets(strModoLectura);
   printf("Captura el Modo de Escritura:"); //wb es el correcto
   gets(strModoEscritura);

   // Abre los 2 Archivos en modo binario
   pFileLectura=fopen("a.exe",strModoLectura);
   pFileEscritura=fopen("b.exe",strModoEscritura);
 
   // Verifica que se hayan podido abrir sin problema los archivos
   if (pFileLectura==NULL||pFileEscritura==NULL)
   {
       // Mensaje de Error
       printf("Error al abrir archivos");
       return 0;
   }

   // Mensaje de Exito al Abrir el Archivo
   printf("Informacion del Archivo de Lectura :\n");
   printf("_ptr     :%s \n",pFileLectura->_ptr);
   printf("_cnt     :%d \n",pFileLectura->_cnt);
   printf("_base    :%s \n",pFileLectura->_base);
   printf("_flag    :%d \n",pFileLectura->_flag);
   printf("_file    :%d \n",pFileLectura->_file);
   printf("_charbuf :%d \n",pFileLectura->_charbuf);
   printf("_bufsiz  :%d \n",pFileLectura->_bufsiz);
   printf("_tmpfname:%s \n\n",pFileLectura->_tmpfname);            
   getch();

   printf("Informacion del Archivo de Escritura :\n");
   printf("_ptr     :%s \n",pFileEscritura->_ptr);
   printf("_cnt     :%d \n",pFileEscritura->_cnt);
   printf("_base    :%s \n",pFileEscritura->_base);
   printf("_flag    :%d \n",pFileEscritura->_flag);
   printf("_file    :%d \n",pFileEscritura->_file);
   printf("_charbuf :%d \n",pFileEscritura->_charbuf);
   printf("_bufsiz  :%d \n",pFileEscritura->_bufsiz);
   printf("_tmpfname:%s \n\n",pFileEscritura->_tmpfname);            
   getch();

 
   // Ciclo que lee caracteres del Archivo de Lectura hasta EOF
   while ((iCaracter=getc(pFileLectura))!=EOF)
   {
       // Graba el Caracter en el Archivo
       putc(iCaracter,pFileEscritura);
       printf("[%d-%d]",iCaracter,iCuenta);

       // Verifica si es negativo
       if (iCaracter < 0)
       {
           printf("Se encontró un valor negativo en el byte:%d",iCuenta+1);
           getch();
       }
       
       // Verifica si es donde existe el carcater sustitute
       if (iCaracter==26)  // Caracter que modo texto indica el error
       {
           // Pausa en el Caracter que provoca el EOF
           getch();
       }

       // Incrementa el Contador de Caracteres
       iCuenta++;
   }
 
   // Mensaje de Finalización
   printf("Fin de lectura de Archivo \n");
   printf("Caracteres Leidos-Grabados:%d \n",iCuenta);

   // Cierra los archivos
   fclose(pFileLectura);
   fclose(pFileEscritura);
   
   // Finaliza la Aplicación
   return 0;
}