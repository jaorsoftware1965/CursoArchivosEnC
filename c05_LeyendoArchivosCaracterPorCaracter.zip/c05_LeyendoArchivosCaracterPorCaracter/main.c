// Curso de Archivos en C
// c05 Leyendo Archivos Caracter por Caracter

// En las clases a continuación, veremos como realizar escritura y lectura de archivos.

// Las Funciones empleadas para archivos de texto son las siguientes:
// fgetc y fputc.    Para leer y escribir un caracter respectivamente.
// fgets y fputs.    Para leer y escribir una cadena.
// fscanf y fprintf. Para lectura y escritura con formato.

// Las Funciones empleadas para archivos binarios son:
// fread y fwrite. Para lectura y escritura de bloques de byte's.

// En esta clase veremos como leer un Archivo de Texto caracter por caracter
// La sintaxis de la función para leer un caracter es:
// int fgetc(FILE *pFile);

// La función devuelve el caracter leído, y necesita como parámetro el apuntador a FILE.
// Si un error ocurre devuelve o alcanza el fin de Archivo, devuelve EOF

// Incluimos la librería de Entrada y Salida Estandar de C
#include "stdio.h"

// Función Principal de C
int main()
{
    // Mensaje de la Aplicación
    printf("c05 Leyendo Archivos Caracter Por Caracter \n");

    // Declaramos la Variable del Puntero a File
    FILE *pFile;

    // Variable para contar los carateres
    int iCuenta=0;

    // Para leer caracter
    int iCaracter;

    // Abrimos este mismo archivo para lectura
    pFile = fopen("archivo.txt","r");
    //pFile = fopen("a.exe","r"); Descomentar esta linea para probar que no se lee el .exe

    // Verifica que pudo abrir el Archivo
    if (pFile==NULL)
    {
        // Mensaje de que hubo un error
        printf("Error al Abrir el Archivo de Lectura \n");
    }
    else
    {
        // Ciclo para leer los caracteres hasta el final
        while (!feof(pFile))
        {
            // Lee un caracter
            iCaracter = fgetc(pFile);

            // Imprime el Caracter a la pantalla
            printf("[%c][%d]",iCaracter,iCaracter);
            //printf("[%d]",iCaracter); // descomentar esta linea al leer .EXE
                        
            // Incrementa el contador de caracteres
            iCuenta++;

            // Mensaje de Exito al Abrir el Archivo
            // printf("Informacion de la Estructura del Archivo:\n");
            // printf("_ptr     :%s \n",pFile->_ptr);
            // printf("_cnt     :%d \n",pFile->_cnt);
            // printf("_base    :%s \n",pFile->_base);
            // printf("_flag    :%d \n",pFile->_flag);
            // printf("_file    :%d \n",pFile->_file);
            // printf("_charbuf :%d \n",pFile->_charbuf);
            // printf("_bufsiz  :%d \n",pFile->_bufsiz);
            // printf("_tmpfname:%s \n",pFile->_tmpfname);
            
        }        
        printf("\nFin de Archivo \n");
        printf("Caracteres en el archivo:%d",iCuenta);
        // Cierra el Archivo
        fclose(pFile);    
    }
    // Salida de la Aplicación
    return 0;
}