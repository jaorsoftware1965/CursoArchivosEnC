// Curso de Archivos en C
// c13 Programa que Lee Graba y Mueve el Apuntador del Archivo

// En la clase anterior se quedó pendiente la sintaxis de la función fflush:

// int fflush ( FILE * stream );

// La función devuelve 0 en caso que haya tenido éxito y valor negativo en caso
// de que haya habido un error.


// Incluimos la librería de Entrada y Salida Estandar de C
#include "stdio.h"

// Incluimos la libreria para funciones de Cadenas
#include "string.h"

// Función Principal
int main()
{    
   // Imprime mensaje de la Clase
   printf("C13 Programa que Lee Graba y Mueve el Apuntador del Archivo\n\n");

   // Variable para archivo    
   FILE *pFile;
   
   // Para saber cuantos caracteres se grabaron o cuantas variables se leyeron
   int iLongitudArchivo;

   // Para posición del Archivo
   int iPosicion;

   // Para el Comando
   int iComando;

   // Para indicar los caracteres
   int iCaracteres;

   // Para lectura del Caracter
   char cCaracter;
      
   // Abre el Archivo
   pFile = fopen ("Datos.txt", "r+");
   
   // Verifica que haya podido abrir el archivo
   if (pFile == NULL) 
   {
       // Mensaje de Error
       printf("Error al abrir el Archivo \n");
   }   
   else 
   {
       // Se posiciona en el final del Archivo
       fseek(pFile,0,SEEK_END);

       // Obtiene la Longitud del Archivo
       iLongitudArchivo = ftell(pFile);

       // Desplegando la informción
       printf("La longitud del Archivo es:%d\n",iLongitudArchivo);

       // Se posiciona en el principio del Archivo
       fseek(pFile,0,SEEK_SET);

       // Ciclo para comandos
       do
       {
           // Obtiene la posición actual
           iPosicion = ftell(pFile);

           // Despliega posición actual
           printf("La posicion actual es:%d\n",iPosicion);

           // Despliega los comandos
           printf("Comandos: A-Adelantar, R-Retroceder, L-Leer, B-Borrar, F-Finalizar\n");
           printf("Captura Comando:");

           // Captura el Comando
           iComando = getch();

           // Cambia de línea
           printf("\n");

           // Verifica comando
           switch(iComando)
           {
                // Adelantar
                case 'A':
                case 'a':
                    // Solicita caracteres a adelantar
                    printf("Indica cuantos caracteres a Adelantar:\n");
                    scanf("%d",&iCaracteres);

                    // Verifica que no se desborde del Archivo
                    if (iPosicion + iCaracteres > iLongitudArchivo)
                    {
                        // Mensaje
                        printf("Los Caracteres indicados rebasan el límite del Archivo\n");                        
                    }
                    else
                    {
                        // Intenta realizar el movimiento
                        if (fseek(pFile,iCaracteres,SEEK_CUR)==0)
                        {
                            // Mensaje de éxito
                            printf("Se ha desplazado el Apuntador del Archivo \n");
                        }
                        else
                        {
                            // Mensaje de éxito
                            printf("Ha ocurrido un Error al desplazar el Apuntador \n");
                        }
                    }
                    break;
                
                // Retroceder
                case 'R':
                case 'r':
                    // Solicita caracteres a retroceder
                    printf("Indica cuantos caracteres a Retroceder:\n");
                    scanf("%d",&iCaracteres);

                    // Verifica que no se desborde del Archivo
                    if (iPosicion - iCaracteres < 0)
                    {
                        // Mensaje
                        printf("Los Caracteres indicados rebasan el principio del Archivo\n");                        
                    }
                    else
                    {
                        // Intenta realizar el movimiento
                        if (fseek(pFile,iCaracteres*-1,SEEK_CUR)==0)
                        {
                            // Mensaje de éxito
                            printf("Se ha desplazado el Apuntador del Archivo \n");
                        }
                        else
                        {
                            // Mensaje de éxito
                            printf("Ha ocurrido un Error al desplazar el Apuntador \n");
                        }
                    }
                    break;

                // Leer
                case 'L':
                case 'l':
                    // Solicita caracteres a Leer
                    printf("Indica cuantos caracteres a Leer:\n");
                    scanf("%d",&iCaracteres);

                    // Verifica que no se desborde del Archivo
                    if (iPosicion + iCaracteres > iLongitudArchivo)
                    {
                        // Mensaje
                        printf("Los Caracteres indicados rebasan el límite del Archivo\n\n");                        
                    }
                    else
                    {
                        // Mensaje de imprimiendo caracteres
                        printf("Caracteres leidos:");

                        // Ciclo para leer los caracteres
                        while (iCaracteres>0)
                        {
                            // Lee caracter por caracter
                            fscanf(pFile,"%c",&cCaracter);
                            
                            // Imprime el caracter
                            printf("%c",cCaracter);

                            // Decrementa el Contador
                            iCaracteres--;
                        }
                        // Cambia de línea
                        printf("\n");
                    }
                    break;

                // Borrar
                case 'B':
                case 'b':
                    // Solicita caracteres a Borrar
                    printf("Indica cuantos caracteres a Borrar:\n");
                    scanf("%d",&iCaracteres);

                    // Verifica que no se desborde del Archivo
                    if (iPosicion + iCaracteres > iLongitudArchivo)
                    {
                        // Mensaje
                        printf("Los Caracteres indicados rebasan el límite del Archivo\n\n");                        
                    }
                    else
                    {
                        // Mensaje de imprimiendo caracteres
                        printf("Borrando Caracteres ...\n");

                        // Ciclo para borrar los caracteres
                        while (iCaracteres>0)
                        {
                            // Lee caracter por caracter
                            fprintf(pFile,"%c",'*');
                            
                            // Decrementa el Contador
                            iCaracteres--;
                        }
                        // Flush
                        fflush(pFile);                        
                    }
                    break;
                    
                case 'F':
                case 'f':
                    // Mensaje de Salida
                    printf("Saliendo de la Aplicacion ...");
                    break;
                default:
                    // Mensaje de Error en Comando
                    printf("Comando Desconocido ...\n");
                    break;
           }        
       }while (iComando !='F' && iComando!='f');
                     
       // Cierra el Archivo
       fclose(pFile);       
   }   
   // Finaliza la Aplicación
   return 0;
}