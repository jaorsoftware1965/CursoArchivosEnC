// Curso de Archivos en C
// c03 Abriendo Archivos II

// En esta clase veremos una variante de los 3 modos de apertura de archivo vistos.
// Esta variante consiste en agregar el símbolo + al modo de apertura ampliando su operación

// ----------------------------------------------------------------------------------
// Modo     Operación
// ----------------------------------------------------------------------------------
// r+       Abre un archivo de texto para lectura y escritura. Si no existe marca error            
// w+       Crea un archivo de texto para escritura y lectura.  Si existe lo sobreescribe y si no lo crea
// a+       Abre un archivo de texto para añadir al final y para lectura. Si no existe lo crea


// Incluimos la librería de Entrada y Salida Estandar de C
#include "stdio.h"

// Función Principal de C
int main()
{
    // Mensaje de la Aplicación
    printf("c03 Abriendo Archivos II \n");

    // Declaramos la Variable del Puntero a File
    FILE *pFile;
    FILE *pFile2;
    FILE *pFile3;

    // Abrimos este mismo archivo para lectura
    pFile = fopen("main.c","r+");

    // Verifica que pudo abrir el Archivo
    if (pFile==NULL)
    {
        // Mensaje de que hubo un error
        printf("Error al Abrir el Archivo de Lectura y Escritura \n");
    }
    else
    {
        // Mensaje de Exito al Abrir el Archivo
        printf("El archivo se abrio correctamente de Lectura y Escritura \n");
        printf("Informacion de la Estructura del Archivo:\n");
        printf("_ptr     :%s \n",pFile->_ptr);
        printf("_cnt     :%d \n",pFile->_cnt);
        printf("_base    :%s \n",pFile->_base);
        printf("_flag    :%d \n",pFile->_flag);
        printf("_file    :%d \n",pFile->_file);
        printf("_charbuf :%d \n",pFile->_charbuf);
        printf("_bufsiz  :%d \n",pFile->_bufsiz);
        printf("_tmpfname:%s \n",pFile->_tmpfname);            

        // Cierra el Archivo
        fclose(pFile);    

    }

    // Abrimos este mismo archivo para añadir al final
    pFile2 = fopen("archivo.txt","w+");
    
    // Verifica que pudo abrir el Archivo
    if (pFile2==NULL)
    {
        // Mensaje de que hubo un error
        printf("Error al Abrir el Archivo para Escritura y Lectura \n");
    }
    else
    {
        // Mensaje de Exito al Abrir el Archivo
        printf("El archivo se abrio correctamente para Escritura y Lectura\n");
        printf("Informacion de la Estructura del Archivo:\n");
        printf("_ptr     :%s \n",pFile2->_ptr);
        printf("_cnt     :%d \n",pFile2->_cnt);
        printf("_base    :%s \n",pFile2->_base);
        printf("_flag    :%d \n",pFile2->_flag);
        printf("_file    :%d \n",pFile2->_file);
        printf("_charbuf :%d \n",pFile2->_charbuf);
        printf("_bufsiz  :%d \n",pFile2->_bufsiz);
        printf("_tmpfname:%s \n",pFile2->_tmpfname);            

        // Cierra el Archivo
        fclose(pFile2);    
    }

    // Abrimos este mismo archivo para añadir al final
    pFile3 = fopen("main2.c","a+");
    
    // Verifica que pudo abrir el Archivo
    if (pFile3==NULL)
    {
        // Mensaje de que hubo un error
        printf("Error al Abrir el Archivo para Agregar al final y Lectura \n");
    }
    else
    {
        // Mensaje de Exito al Abrir el Archivo
        printf("El archivo se abrio correctamente para Agregar al final y Lectura\n");
        printf("Informacion de la Estructura del Archivo:\n");
        printf("_ptr     :%s \n",pFile3->_ptr);
        printf("_cnt     :%d \n",pFile3->_cnt);
        printf("_base    :%s \n",pFile3->_base);
        printf("_flag    :%d \n",pFile3->_flag);
        printf("_file    :%d \n",pFile3->_file);
        printf("_charbuf :%d \n",pFile3->_charbuf);
        printf("_bufsiz  :%d \n",pFile3->_bufsiz);
        printf("_tmpfname:%s \n",pFile3->_tmpfname);            

        // Cierra el Archivo
        fclose(pFile3);    

    }
        
    // Salida de la Aplicación
    return 0;
}