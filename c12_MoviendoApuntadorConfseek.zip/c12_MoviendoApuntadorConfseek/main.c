// Curso de Archivos en C
// c12 Moviendo el Apuntador con fseek

// En la clase anterior, se aprendió que es posible mover el apuntador del Archivo al principio
// utilizando la función rewind.

// Existe otra función que nos permite colocar el apuntador en la posición del archivo que
// querramos y es la función fseek. Esta es su sintaxis:

// int fseek ( FILE *stream, long int offset, int origin );

// Esta función devuelve 0 si el posicionamiento fue correcto y un valor distinto de 0 en caso
// de que haya habido error.

// El parámetro *stream es el apuntador del archivo del cual se desea posicionar el apuntador.
// El parámetro offset es el desplazamiento en bytes que se desea realizar. Puede ser negativo.
// El parámetro origin indica a partir de que punto se desea realizar el desplazamiento y los
// valores posibles están indicados por las siguientes constantes

// SEEK_SET. El desplazamiento se realizará desde el principio del archivo.
// SEEK_CUR. El desplazamiento se realizará desde la posicion actual del apuntador de archivo.
// SEEK_END. El desplazamiento se realizará desde el fin del archivo.


// Incluimos la librería de Entrada y Salida Estandar de C
#include "stdio.h"

// Incluimos la libreria para funciones de Cadenas
#include "string.h"

// Función Principal
int main()
{    
   // Imprime mensaje de la Clase
   printf("C12 Moviendo el Apuntador del Archivo con fseek\n \n");

   // Variable para archivo    
   FILE *pFile;

   // Datos a Grabar en el Archivo
   char  strNombre[21]="Juan";
   char  strApellido[21]="Escutia";   
   int   intEdad=45;
   float fltPeso=75.40;
   char  chrSexo='H';
   char  chrEdoCivil='C';

   // Para saber cuantos caracteres se grabaron o cuantas variables se leyeron
   int iContador=0;

   // Para posición del Archivo
   int iPosicion=0;
   
   // Para Registro a Visitar
   int iRegistroVisitar=0;

   // Longitud del Registro
   const int LONGITUD_REGISTRO = 53;
   
   // Abre el Archivo Original
   pFile = fopen ("Datos.txt", "w+");
   
   // Verifica que haya podido abrir el archivo
   if (pFile == NULL) 
   {
       // Mensaje de Error
       printf("Error al abrir el Archivo \n");
   }   
   else 
   {
       // Posición del Archivo
       iPosicion = ftell(pFile);

       // Despliega la posición del achivo
       printf("Posición del Apuntador al Crear el Archivo :%d \n",iPosicion);
       getch();

       // Graba los datos
       printf("Grabando el Primer Registro de: %s \n",strNombre);       
       iContador = fprintf(pFile, "%-20s%-20s%03d%07.2f%c%c\n",strNombre,strApellido,intEdad,fltPeso,chrSexo,chrEdoCivil);       
       fflush(pFile);

       // Despliega cuantos caracteres se grabaron
       printf("Caracteres grabados:%d \n",iContador);
       
       // Despliega la posición del achivo
       iPosicion = ftell(pFile);       
       printf("Posición del Apuntador:%d \n",iPosicion);
       getch();
       

       // Actualizamos a otros datos
       strcpy(strNombre, "Diana");       
       strcpy(strApellido, "Flores");
       intEdad = 49;
       fltPeso = 80.50;
       chrSexo ='M';
       chrEdoCivil='S';
    
       // Graba los datos
       printf("Grabando el Segundo Registro de: %s \n",strNombre);       
       iContador = fprintf(pFile, "%-20s%-20s%03d%07.2f%c%c\n",strNombre,strApellido,intEdad,fltPeso,chrSexo,chrEdoCivil);
       fflush (pFile);
              
       // Despliega cuantos caracteres se grabaron
       printf("Caracteres grabados:%d \n",iContador);

       // Despliega la posición del achivo
       iPosicion = ftell(pFile);       
       printf("Posición del Apuntador:%d \n",iPosicion);
       getch();
              
       // Retorna el apuntador del Archivo al Principio
       printf("Retornando al Principio del Archivo \n",strNombre);       
       rewind(pFile);

       // Despliega la posición del achivo
       iPosicion = ftell(pFile);       
       printf("Posición del Apuntador al hacer rewind:%d \n",iPosicion);
       getch();
       
       // Lee los datos       
       printf("Leyendo el Registro 1 \n");       
       iContador = fscanf (pFile, "%20s%20s%3d%7f%c%c",strNombre,strApellido,&intEdad,&fltPeso,&chrSexo,&chrEdoCivil);
       
       // Despliega cuantas variables se Leyeron
       printf("Variables Leidas:%d \n",iContador);

       // Despliega la posición del achivo
       iPosicion = ftell(pFile);       
       printf("Posición del Apuntador:%d \n",iPosicion);
       getch();
                            
       // Imprimiendo los datos
       printf("Nombre:%s Apellido:%s Edad:%d Peso:%f ",strNombre,strApellido,intEdad,fltPeso);
       printf("Sexo:%c EdoCivil:%c\n\n",chrSexo,chrEdoCivil);
              
       // Lee los datos
       printf("Leyendo el Registro 2 \n");       
       iContador = fscanf (pFile, "%20s%s%3d%7f%c%c",strNombre,strApellido,&intEdad,&fltPeso,&chrSexo,&chrEdoCivil);
                     
       // Despliega cuantas variables se Leyeron
       printf("Variables Leidas:%d \n",iContador);

       // Despliega la posición del achivo
       iPosicion = ftell(pFile);       
       printf("Posición del Apuntador:%d \n",iPosicion);       
       getch();

       // Imprimiendo los datos
       printf("Nombre:%s Apellido:%s Edad:%d Peso:%f ",strNombre,strApellido,intEdad,fltPeso);
       printf("Sexo:%c EdoCivil:%c\n",chrSexo,chrEdoCivil);

       // Retorna el apuntador del Archivo al Principio
       printf("Retornando al Principio del Archivo \n");       
       fseek(pFile,0,SEEK_SET);

       // Despliega la posición del achivo
       iPosicion = ftell(pFile);       
       printf("Posición del Apuntador al hacer fseek al Inicio:%d \n",iPosicion);
       getch();

       // Actualizamos a otros datos
       strcpy(strNombre, "Pedro");       
       strcpy(strApellido, "Picapiedra");
       intEdad = 99;
       fltPeso = 188.50;
       chrSexo ='X';
       chrEdoCivil='Y';
    
       // Graba los datos
       printf("Regrabando el Registro 1 con:%s \n",strNombre);       
       iContador = fprintf(pFile, "%-20s%-20s%03d%07.2f%c%c\n",strNombre,strApellido,intEdad,fltPeso,chrSexo,chrEdoCivil);
       fflush(pFile);
              
       // Despliega cuantos caracteres se grabaron
       printf("Caracteres grabados:%d \n",iContador);

       // Despliega la posición del achivo
       iPosicion = ftell(pFile);       
       printf("Posición del Apuntador:%d \n",iPosicion);    
       getch();
       
       // Nos movemos al final del Archivo
       fseek(pFile,0,SEEK_END);

       // Despliega la posición del achivo
       iPosicion = ftell(pFile);       
       printf("Posición del Apuntador al Movernos al Final del Archivo:%d \n",iPosicion);
       getch();

       // Actualizamos a otros datos
       strcpy(strNombre, "Pablo");       
       strcpy(strApellido, "Marmol");
       intEdad = 89;
       fltPeso = 158.50;
       chrSexo ='W';
       chrEdoCivil='Z';
    
       // Graba los datos
       printf("Grabando un Registro al Final del Archivo con:%s \n",strNombre);       
       iContador = fprintf(pFile, "%-20s%-20s%03d%07.2f%c%c\n",strNombre,strApellido,intEdad,fltPeso,chrSexo,chrEdoCivil);
       fflush (pFile);

       // Despliega la posición del achivo
       iPosicion = ftell(pFile);       
       printf("Posición del Apuntador Despues de Grabar al Final del Archivo:%d \n",iPosicion);
       getch();

       // Actualizamos a otros datos
       strcpy(strNombre, "Encimamos2do");       
       strcpy(strApellido, "SobreEscrito");
       intEdad = 55;
       fltPeso = 100.22;
       chrSexo ='R';
       chrEdoCivil='Q';
       iRegistroVisitar = 2;
       fseek(pFile,(iRegistroVisitar-1)*LONGITUD_REGISTRO,SEEK_SET);
       iContador = fprintf(pFile, "%-20s%-20s%03d%07.2f%c%c\n",strNombre,strApellido,intEdad,fltPeso,chrSexo,chrEdoCivil);
       fflush(pFile);
       
       // Despliega cuantos caracteres se grabaron
       printf("Caracteres grabados Encima:%d \n",iContador);
              
       // Cierra el Archivo
       fclose(pFile);       
   }   
   // Finaliza la Aplicación
   return 0;
}