// Curso de Archivos en C
// c08 Escribiendo Archivos Línea por Línea

// En esta clase veremos como leer un Archivo Línea por Línea y como Escribir en otro
// archivo Línea por Línea, para obtener una copia del primero.

// Para grabar una Línea en un archivo hacemos uso de la función fputs, la cual 
// graba en el archivo una cadena.

// Esta función tiene la siguiente sintaxis:
// int fputs(const char *cadena, FILE *stream);

// Lo primero que observamos es que la función devuelve un valor entero, que si es igual
// a EOF es que hubo un error al grabar.

// El primer parámetro es la cadena que se va a grabar al archivo y el segundo es el 
// apuntador a FILE.

// Incluimos la librería de Entrada y Salida Estandar de C
#include "stdio.h"

// Incluimos la libreria para funciones de Cadenas
#include "string.h"

// Función Principal
int main()
{
   // Imprime mensaje de la Clase
   printf("C08 Escribiendo Archivos Linea por Linea \n");

   // Variable para archivo 
   FILE *pFileLectura;
   FILE *pFileEscritura;

   // Variable para Leer datos desde el Archivo
   char strLinea [100];

   // Variable para Contar Caracteres
   int iCuentaCaracteres=0;

   // Variable para Contar Líneas
   int iCuentaLineas=0;   

   // Nombre del Archivo Original
   char strArchivoOriginal[50];

   // Nombre del Archivo Copiado
   char strArchivoCopia[50];

   // Solicita el nombre del Archivo a Copiar
   puts("Nombre del Archivo a Copiar");
   gets(strArchivoOriginal);

   // Valida que haya capturado
   if (strlen(strArchivoOriginal)<=0)
   {
       // Mensaje de que falta el archivo
       puts("Debe indicar el archivo");

       //Salimos de la aplicación
       return 0;
   }

   // Crea el nombre del Archivo Copia
   strcpy(strArchivoCopia,"Copy");
   strcat(strArchivoCopia,strArchivoOriginal);

   // Abre el Archivo Original
   pFileLectura = fopen (strArchivoOriginal , "r");

   // Verifica que haya podido abrir el archivo
   if (pFileLectura == NULL) 
   {
       // Mensaje de Error
       printf("Error al abrir el Archivo %s \n",strArchivoOriginal);
   }   
   else 
   {
      // Abre el Archivo para Copia
      pFileEscritura = fopen (strArchivoCopia, "w");
   
      // Verifica que haya podido abrir el archivo
      if (pFileEscritura == NULL) 
      {
          // Mensaje de Error
          printf("Error al crear el Archivo Copia %s \n",strArchivoCopia);
      }   
      else 
      {   
        // Mensaje de despliegue del Archivo
        printf("Leyendo y Copiando ...");

        // Intenta leer una Línea
        while (fgets(strLinea, 100 , pFileLectura) != NULL )
        {            
            // Incrementa el Contador de Caracteres
            iCuentaCaracteres = iCuentaCaracteres + strlen(strLinea);
            
            // Incrementa el Contador de Lineas
            iCuentaLineas++;

            // Despliega Mensajes
            printf("Leyendo Línea     :%d \n",iCuentaLineas);
            printf("Caracteres Leídos :%d \n",iCuentaCaracteres);

            // Intenta grabar en el archivo
            if (fputs(strLinea, pFileEscritura)==EOF)
            {
                // Mensaje de Error
                printf("Ocurrió un Error al Grabar en el Archivo");

                // Sale de la Aplicación
                return 0;            
            }
            
            // Mensaje de Grabación
            printf("Grabando ...\n\n");
            
            if (iCuentaLineas==119)
               fputs("<Linea 120", pFileEscritura);
        }//while

        // Cierra el Archivo    
        fclose (pFileLectura);        
        fclose (pFileEscritura);
      }//else
   }

   // Mensaje de finalización
   printf("\nSe ha finalizado la Lectura del Archivo \n");
   printf("Lineas leidas/grabadas   :%d \n",iCuentaLineas);
   printf("Caracteres leidos/grbados:%d \n",iCuentaCaracteres);
   printf("Tamaño del Archivo       :%d \n",iCuentaCaracteres+iCuentaLineas-1);

   // Finaliza la Aplicación
   return 0;
}