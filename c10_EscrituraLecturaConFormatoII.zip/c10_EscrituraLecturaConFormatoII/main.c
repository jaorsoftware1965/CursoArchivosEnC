// Curso de Archivos en C
// c10 Escritura y Lectura con Formato II

// En esta clase veremos la lectura y escritura de Archivos aplicando formato
// a cada uno de los datos que se están grabando

// Incluimos la librería de Entrada y Salida Estandar de C
#include "stdio.h"

// Incluimos la libreria para funciones de Cadenas
#include "string.h"

// Función Principal
int main()
{
    
   // Imprime mensaje de la Clase
   printf("C10 Escribiendo y Leyendo con Formato II\n \n");

   // Variable para archivo    
   FILE *pFile;

   // Datos a Grabar en el Archivo
   char  strNombre[21]="Juan Alberto";
   char  strApellido[21]="Escutia";   
   int   intEdad=45;
   float fltPeso=75.40;
   char  chrSexo='H';
   char  chrEdoCivil='C';

   // Para saber cuantos caracteres se grabaron o cuantas variables se leyeron
   int iContador=0;
   
   // Abre el Archivo Original
   pFile = fopen ("Datos.txt", "w+");
   
   // Verifica que haya podido abrir el archivo
   if (pFile == NULL) 
   {
       // Mensaje de Error
       printf("Error al abrir el Archivo \n");
   }   
   else 
   {
       // Graba los datos
       iContador = fprintf(pFile, "%-20s %-20s %03d %07.2f %c %c\n",strNombre,strApellido,intEdad,fltPeso,chrSexo,chrEdoCivil);

       // Despliega cuantos caracteres se grabaron
       printf("Caracteres grabados:%d \n",iContador);

       // Actualizamos a otros datos
       strcpy(strNombre, "Diana");       
       strcpy(strApellido, "Flores");
       intEdad = 49;
       fltPeso = 80.50;
       chrSexo ='M';
       chrEdoCivil='S';
    
       // Graba los datos
       iContador = fprintf(pFile, "%-20s %-20s %03d %07.2f %c %c\n",strNombre,strApellido,intEdad,fltPeso,chrSexo,chrEdoCivil);
              
       // Despliega cuantos caracteres se grabaron
       printf("Caracteres grabados:%d \n",iContador);
       
       // Retorna el apuntador del Archivo al Principio
       rewind(pFile);

       // Lee los datos       
       //iContador = fscanf (pFile, "%s %s %d %f %c %c",strNombre,strApellido,&intEdad,&fltPeso,&chrSexo,&chrEdoCivil);
       fgets(strNombre,20,pFile);
       iContador = fscanf (pFile, "%s %d %f %c %c",strApellido,&intEdad,&fltPeso,&chrSexo,&chrEdoCivil);

       // Despliega cuantas variables se Leyeron
       printf("Variables Leidas:%d \n",iContador);
              
       // Imprimiendo los datos
       printf("Nombre:%s Apellido:%s Edad:%d Peso:%f ",strNombre,strApellido,intEdad,fltPeso);
       printf("Sexo:%c EdoCivil:%c\n\n",chrSexo,chrEdoCivil);

       // Lee los datos
       iContador = fscanf (pFile, "%s %s %d %f %c %c",strNombre,strApellido,&intEdad,&fltPeso,&chrSexo,&chrEdoCivil);
       
       
       // Despliega cuantas variables se Leyeron
       printf("Variables Leidas:%d \n",iContador);

       // Imprimiendo los datos
       printf("Nombre:%s Apellido:%s Edad:%d Peso:%f ",strNombre,strApellido,intEdad,fltPeso);
       printf("Sexo:%c EdoCivil:%c\n",chrSexo,chrEdoCivil);

       // Cierra el Archivo
       fclose(pFile);       
   }   
   // Finaliza la Aplicación
   return 0;
}
