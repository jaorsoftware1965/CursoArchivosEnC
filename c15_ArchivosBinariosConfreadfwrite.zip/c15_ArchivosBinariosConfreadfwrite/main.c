// Curso de Archivos en C
// c15 fread y fwrite

// El Manejo de las funciones fwrite y fread, es un poco mas complejo que las
// funcions vistas anteriormente.

// Estas 2 funciones leer/graban "x" cantidad de elementos de un tamaño específico
// A continación se presenta la sintaxis del uso de las 2 funciones

// Sintaxis de fwrite
// size_t fwrite ( const void * ptr, size_t size, size_t count, FILE * stream );


// Sintaxis de fread
// size_t fread ( void * ptr, size_t size, size_t count, FILE * stream );

// ptr    Es el apuntador que contiene los datos a leer o escribir
// size   Es el tamaño en bytes de cada uno de los elementos a leer/grabar
// count  Es el numero de elementos a leer grabar
// stream Es el apuntador a FILE

// El Valor de retorno de la función debe ser igual a count; es decir; al número de elementos
// que intentó leer; si es menor o 0 es que ocurrió una lectura en los datos

// En esta clase veremos un ejemplo sencillo, el cual nos servirá para copiar
// de una sola instrucción, un archivo.


// Incluimos las librerias necesarias
#include "stdio.h"

// Para manejo de memoria dinámica
#include "stdlib.h"

// Función principal
int main () 
{
  
  // Apuntadores a FILE
  FILE *pFileLectura;
  FILE *pFileEscritura;
  
  // Variable para la Longitud en Bytes del Elemento a Grabar
  long   lLongitudElementoGrabar;
  
  // Buffer donde se almacena la información a grabar
  char   *bufferDatos;
  
  // Elementos a grabar
  int iElementos=1;
  
  // Resultado
  size_t resultado;

  // Mensaje de Apertura de Archivos
  printf("Abriendo Archivos ...\n");
  
  // Abrimos el archivo en modo binario de Lectura
  pFileLectura = fopen ( "a.exe" , "rb" );
  
  // Abrimos el archivo en modo binario de Escritura
  pFileEscritura = fopen ( "b.exe" , "wb" );
  
  // Verifica pertura correcta
  if (pFileLectura==NULL || pFileEscritura ==NULL) 
  {
	  // Mensaje de Error
	  printf ("Error en Apertura de Archivos"); 
	  return 0;	  
  }

  // Mensaje de obteniendo tamaño del Archivo
  printf("Obteniendo longitud del Archivo ...\n");
  
  // Nos posicionamos al fin del Archivo
  fseek (pFileLectura , 0 , SEEK_END);
  
  // Obtenemos su longitud
  lLongitudElementoGrabar = ftell (pFileLectura);
  
  // Imprimiendo longitud
  printf("Longitud %ld \n",lLongitudElementoGrabar);   
  
  // Colocamos el apuntador al principio
  rewind (pFileLectura);

  // Reservamos memoria dinámicamente de acuerdo a la longitud del archivo
  bufferDatos = (char*) malloc (sizeof(char)*lLongitudElementoGrabar);
  
  // Verificamos que haya sido correcta
  if (bufferDatos == NULL) 
  {
	  // Mensaje de Error
	  printf("Error al Reservar Memoria"); 
	  return 0;
  }

  // Leemos el elemento desde el Archivo
  resultado = fread (bufferDatos,lLongitudElementoGrabar,iElementos,pFileLectura);
  
  // Despliega los elementos leídos
  printf("Elementos leidos:%ld \n",resultado);
  
  // Verifica si hubo algún error
  if (resultado != iElementos) 
  {
	  // Mensaje de Error
	  printf("Error al Leer Archivo"); 
	  return 0;	  
  }
  
  // Grabando el Archivo
  printf("Grabando el Archivo ...\n");
  
  // Grabamos el Archivo
  resultado = fwrite (bufferDatos,lLongitudElementoGrabar,iElementos,pFileEscritura);

  // Despliega los elementos grabados
  printf("Elementos grabados:%ld \n",resultado);
  
  // Verifica si hubo algún error
  if (resultado != iElementos) 
  {
	  // Mensaje de Error
	  printf("Error al Grabar Archivo"); 
	  return 0;	  
  }
  
  
  // Cierra el Archivo
  fclose (pFileLectura);
  fclose (pFileEscritura);
  
  // Libera la Memoria
  free (bufferDatos);
  
  // Finaliza la Aplicación
  return 0;
  
}