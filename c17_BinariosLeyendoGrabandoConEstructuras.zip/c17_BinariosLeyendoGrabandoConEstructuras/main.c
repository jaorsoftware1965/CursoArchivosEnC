// Curso de Archivos en C
// c17 BinariosLeyendoGrabandoConEstructuras

// En esta clase veremos como Grabar y Leer Archivos con variables de Estructuras.
// Grabaremos con una variable de tipo Estructura 10 registros y posteriormente
// leeremos los 10 registro al mismo tiempo y los desplegaremos

// Incluimos las librerias necesarias
#include "stdio.h"

// Para manejo de memoria dinámica
#include "string.h"

// Función principal
int main () 
{
	// Definimos la estructura
    struct Persona
    {		
        // Datos a grabar
        char  strNombre[20];
        char  strApellido[20];
        int   intEdad;
        float fltPeso;
        char  chrSexo;
        char  chrEdoCivil;
    };  
    
    // Definimos una variable de Personas
	struct Persona xPersona;
	
	// Definimos un arreglo de 10 Personas
	struct Persona aPersonas[10];
	
    // Longitud del Registro
    int iLongitudRegistro;
    
    // Apuntador a FILE
    FILE *pFile;     
  
    // Elementos a grabar / leer
    int iElementos=1;
  
    // Resultado
    size_t resultado;
	
	// Variable para contar
	int iCuenta;
	
	// Variable para registro
	char sRegistro[5];

    // Mensaje de Apertura de Archivos
    printf("Creando Archivo de Escritura/Lectura...\n");
  
    // Abrimos el archivo en modo binario de Lectura
    pFile = fopen ( "datos.dat" , "wb+" );
  
    // Verifica apertura correcta
    if (pFile ==NULL) 
    {	
	    // Mensaje de Error
	    printf ("Error en Creación de Archivo"); 
	    return 0;	  
    }
  
    // Calculamos la longitud del Registro
    iLongitudRegistro  = sizeof(xPersona);
    printf("Longitud del Registro:%d \n",iLongitudRegistro);
    getch();
      
    // Mensaje de Grabación
    printf("Grabando ... \n");
	
	// Ciclo de Grabación
	for (iCuenta=1; iCuenta<=10; iCuenta++)
	{
		// Que registro está grabando
		printf("Registro %d \n",iCuenta);
		
		// convierte el Contador en String
        itoa(iCuenta, sRegistro, 10);
		
		// Coloca los datos a grabar
	    strcpy(xPersona.strNombre,"Nombre ");
		strcat(xPersona.strNombre,sRegistro);
	    strcpy(xPersona.strApellido,"Apellido");
		strcat(xPersona.strApellido,sRegistro);
	    xPersona.intEdad = 50+iCuenta;
	    xPersona.fltPeso = 82.50+iCuenta;
	    xPersona.chrEdoCivil=47+iCuenta;
	    xPersona.chrSexo=48+iCuenta;

		
		// Intenta Grabar
		resultado = fwrite(&xPersona,iLongitudRegistro,iElementos,pFile);
		
		// Verificamos que no haya habido error
        if (resultado != iElementos)
        {
	        // Mensaje de Error
	        printf("Error al Grabar en el Archivo"); 
	        return 0;	  
        }
		
	}
  
  
    // Colocamos el apuntador al principio
    printf("Posicionando en Principio del Archivo ...\n");
    fseek(pFile,0,SEEK_SET);
    getch();
     
    // Elementos a Leer
    iElementos = 10;
	
	// Mensaje de Grabación
    printf("Leyendo %d Registros \n",iElementos);
  
  
    // Leemos los datos
    resultado = fread (aPersonas,iLongitudRegistro,iElementos,pFile);
  
    // Mensaje de Elementos Leídos
    printf("Elementos Leidos:%d \n",resultado);
	getch();
  
 
    // Validando Error
    if (resultado !=iElementos)
    {
		
	    // Mensaje de Error
	    printf("Error al Leer del Archivo"); 
	    return 0;	  
    }
  
    // Mensaje de despliegue
    printf("Desplegando los Registros ...\n");
  
    // Ciclo para desplegar los Datos
    for (iCuenta=0; iCuenta < iElementos; iCuenta ++)
    {		
	    // Mensaje del registro a desplegar
	    printf("Registro %d\n",iCuenta+1);
	  
	    // Desplegamos los datos
        printf("Nombre    :%s\n",aPersonas[iCuenta].strNombre);
        printf("Apellido  :%s\n",aPersonas[iCuenta].strApellido);
        printf("Edad      :%d\n",aPersonas[iCuenta].intEdad);
        printf("Peso      :%f\n",aPersonas[iCuenta].fltPeso);
        printf("Edo Civil :%c\n",aPersonas[iCuenta].chrEdoCivil);
        printf("Sexo      :%c\n",aPersonas[iCuenta].chrSexo);   
		printf("\n");
		getch();
    }
  
  // Cierra el Archivo
  fclose (pFile);
  
  // Finaliza la Aplicación
  return 0;
  
}