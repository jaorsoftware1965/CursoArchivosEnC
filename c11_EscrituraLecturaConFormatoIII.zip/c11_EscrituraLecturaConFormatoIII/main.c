// Curso de Archivos en C
// c11 Escritura y Lectura con Formato III

// En esta clase veremos la lectura y escritura de Archivos aplicando formato
// a cada uno de los datos que se están grabando y tambien aplicando formato 
// al momento que se está leyendo

// Tambien veremos el uso de la función ftell la cual su sintaxis es la siguiente:

// long int ftell ( FILE * stream );

// Esta función devuelve un valor de 0 o mayor, para indicar la posición del apuntador
// en el archivo. En caso de que haya habido error, devuelve un valor de -1

// Incluimos la librería de Entrada y Salida Estandar de C
#include "stdio.h"

// Incluimos la libreria para funciones de Cadenas
#include "string.h"

// Función Principal
int main()
{
    
   // Imprime mensaje de la Clase
   printf("C11 Escribiendo y Leyendo con Formato III\n \n");

   // Variable para archivo    
   FILE *pFile;

   // Datos a Grabar en el Archivo
   char  strNombre[21]="Juan";
   char  strApellido[21]="Escutia";   
   int   intEdad=45;
   float fltPeso=75.40;
   char  chrSexo='H';
   char  chrEdoCivil='C';

   // Para saber cuantos caracteres se grabaron o cuantas variables se leyeron
   int iContador=0;

   // Para posición del Archivo
   int iPosicion=0;
   
   // Abre el Archivo Original
   pFile = fopen ("Datos.txt", "w+");
   
   // Verifica que haya podido abrir el archivo
   if (pFile == NULL) 
   {
       // Mensaje de Error
       printf("Error al abrir el Archivo \n");
   }   
   else 
   {
       // Posición del Archivo
       iPosicion = ftell(pFile);

       // Despliega la posición del achivo
       printf("Posición del Apuntador al Crear el Archivo :%d \n",iPosicion);
       getch();

       // Graba los datos
       iContador = fprintf(pFile, "%-20s%-20s%03d%07.2f%c%c",strNombre,strApellido,intEdad,fltPeso,chrSexo,chrEdoCivil);       
       
       // Despliega cuantos caracteres se grabaron
       printf("Caracteres grabados:%d \n",iContador);
       
       // Despliega la posición del achivo
       iPosicion = ftell(pFile);       
       printf("Posición del Apuntador:%d \n",iPosicion);
       getch();
       

       // Actualizamos a otros datos
       strcpy(strNombre, "Diana");       
       strcpy(strApellido, "Flores");
       intEdad = 49;
       fltPeso = 80.50;
       chrSexo ='M';
       chrEdoCivil='S';
    
       // Graba los datos
       iContador = fprintf(pFile, "%-20s%-20s%03d%07.2f%c%c",strNombre,strApellido,intEdad,fltPeso,chrSexo,chrEdoCivil);
                     
       // Despliega cuantos caracteres se grabaron
       printf("Caracteres grabados:%d \n",iContador);

       // Despliega la posición del achivo
       iPosicion = ftell(pFile);       
       printf("Posición del Apuntador:%d \n",iPosicion);
       getch();
              
       // Retorna el apuntador del Archivo al Principio
       rewind(pFile);

       // Despliega la posición del achivo
       iPosicion = ftell(pFile);       
       printf("Posición del Apuntador al hacer rewind:%d \n",iPosicion);
       getch();
       
       // Lee los datos       
       iContador = fscanf (pFile, "%20s%20s%3d%7f%c%c",strNombre,strApellido,&intEdad,&fltPeso,&chrSexo,&chrEdoCivil);
       
       // Despliega cuantas variables se Leyeron
       printf("Variables Leidas:%d \n",iContador);

       // Despliega la posición del achivo
       iPosicion = ftell(pFile);       
       printf("Posición del Apuntador:%d \n",iPosicion);
       getch();
                            
       // Imprimiendo los datos
       printf("Nombre:%s Apellido:%s Edad:%d Peso:%f ",strNombre,strApellido,intEdad,fltPeso);
       printf("Sexo:%c EdoCivil:%c\n\n",chrSexo,chrEdoCivil);
              
       // Lee los datos
       iContador = fscanf (pFile, "%20s%20s%3d%7f%c%c",strNombre,strApellido,&intEdad,&fltPeso,&chrSexo,&chrEdoCivil);
                     
       // Despliega cuantas variables se Leyeron
       printf("Variables Leidas:%d \n",iContador);

       // Despliega la posición del achivo
       iPosicion = ftell(pFile);       
       printf("Posición del Apuntador:%d \n",iPosicion);       
       getch();

       // Imprimiendo los datos
       printf("Nombre:%s Apellido:%s Edad:%d Peso:%f ",strNombre,strApellido,intEdad,fltPeso);
       printf("Sexo:%c EdoCivil:%c\n",chrSexo,chrEdoCivil);

       // Cierra el Archivo
       fclose(pFile);       
   }   
   // Finaliza la Aplicación
   return 0;
}