// Curso de Archivos en C
// c07 Leyendo Archivos Línea por Línea

// En esta clase veremos como leer un Archivo Línea por Línea

// Para lograr esto hacemos uso de la función fgets, la cual lee caracteres en el archivo
// hasta encontrarse el cambio de Línea o el fin de archivo.

// Hay que tomar en cuenta que el cambio de linea, es incluido en los caracteres que lee
// la función.

// Esta función tiene la siguiente sintaxis:
// char *fgets ( char * str, int num, FILE * stream );

// Lo primero que observamos es que la función devuelve un apuntador a char; el cual corresponde
// al primer parámetro que utiliza. En caso de error devuelve NULL

// El Primer parámetro deberá ser una variable que es en la cual se almacenará la información
// leída desde el archivo.

// El Segundo parámetro indica el número máximo de caracteres que leera la función del archivo
// Finalmente el Tercer parámetro, es el apuntador a FILE.

// Incluimos la librería de Entrada y Salida Estandar de C
#include "stdio.h"

// Incluimos la libreria para funciones de Cadenas
#include "string.h"

// Función Principal
int main()
{
   // Imprime mensaje de la Clase
   printf("C07 Leyendo Archivos Linea por Linea \n");

   // Variable para archivo 
   FILE * pFile;

   // Variable para Leer datos desde el Archivo
   char strLinea [100];

   // Variable para Contar Caracteres
   int iCuentaCaracteres=0;

   // Variable para Contar Líneas
   int iCuentaLineas=0;   

   // Abre el Archivo
   pFile = fopen ("archivo.txt" , "r");

   // Verifica que haya podido abrir el archivo
   if (pFile == NULL) 
   {
       // Mensaje de Error
       printf("Error al abrir el Archivo \n");
   }   
   else 
   {
       // Mensaje de despliegue del Archivo
       printf("Desplegando el Archivo ...");

       // Intenta leer una Línea
       while (fgets(strLinea, 100 , pFile) != NULL )
       {
           // Despliega la Línea
           printf("%s",strLinea);

           // Incrementa el Contador de Caracteres
           iCuentaCaracteres = iCuentaCaracteres + strlen(strLinea);
           
           // Incrementa el Contador de Lineas
           iCuentaLineas++;
       }

       // Cierra el Archivo    
       fclose (pFile);
   }

   // Mensaje de finalización
   printf("\nSe ha finalizado la Lectura del Archivo \n");
   printf("Lineas leidas:%d \n",iCuentaLineas);
   printf("Caracteres leidos:%d \n",iCuentaCaracteres);
   printf("Tamaño del Archivo:%d \n",iCuentaCaracteres+iCuentaLineas-1);

   // Finaliza la Aplicación
   return 0;
}