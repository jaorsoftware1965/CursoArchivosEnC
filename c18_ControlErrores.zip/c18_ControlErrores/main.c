// Curso de Archivos en C
// c18 Control de Errores
// Clase Final del Curso

// En esta clase veremos como controlar en forma mas detallada el manejo de Errores

// A la fecha solo hemos visto como detectar errores a través de los valores que
// retornan las funciones de archivo que hemos visto; pero ahora veremos otra forma
// de detectar los errores y desplegar la descripción del mismo.

// Para controlar el error, algunas funciones activan un indicador de error, el cual puede
// ser verificado con la función ferror, la cual tiene la siguiente sintaxis

// int ferror(FILE *stream)

// Esta función devuelve el valor del Error registrado por la función; el cual debe ser un
// valor mayor que 0.

// La descripción del error, puede ser accedida desde la función perror, la cual tiene
// la siguiente sintaxis:

// void perror ( const char * str );

// Esta función recibe como parámetro una cadena, la cual sirve para indicar el error; y que
// es colocada previamente a la descripción del error.

// Las siguientes tabla muestra las funciones que Si-No activan el indicador de error

// ----------------------------------------------
// Función				Activa indicador de Error
// ----------------------------------------------
// fopen				No
// fclose				No
// fputc,  fgetc      	Si
// fgets,  fputs.   	Si
// fscanf, fprintf      Si
// fwrite, fread        Si

// Nota. Todas las funciones cuando generan error, activan la descripción utilizada por perror


// Incluimos las librerias necesarias
#include "stdio.h"

// Función principal
int main () 
{
        
    // Apuntador a FILE
    FILE *pFile;   

    // Para el nombre del Archivo
    char sArchivo[30];	
  
    // Mensaje de Apertura de Archivos
    printf("Capture el Archivo a abrir:\n");
	gets(sArchivo);
  
    // Abrimos el archivo en modo de Lectura
    pFile = fopen ( sArchivo , "r" );
	
	// Verifica apertura correcta
    if (pFile == NULL) 
    {	
	    // Mensaje de Error
		perror ("Error en apertura de archivo ");
	    return 0;	  
    }
	else
	{
		// Intenta grabar pero el archivo es solo de lectura
	    fputc ('x',pFile);
		
		// Valida de otra forma el error
        if (ferror(pFile))
		{
			printf("Error Num : %d\n",ferror(pFile));
		    perror("Error Dsc ");		   
		}
	}
      
    // Cierra el Archivo
    fclose (pFile);
  
    // Finaliza la Aplicación
    return 0;
}